How to run this program using Java.
Ensure Java is installed on your machine. Open command line or an ssh client and navigate to the source file (TracerouteAnalysis.java)
Run the following command:

javac TracerouteAnalysis.java

This will compile the TracerouteAnalysis file. After this, run the command 

java TracerouteAnalysis

and it will execute the program.